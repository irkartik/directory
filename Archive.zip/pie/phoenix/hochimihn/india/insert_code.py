# -----------------------------------------------
# IMPORT REQUIRED LIBRARY
# -----------------------------------------------
import pymysql

# -----------------------------------------------
# FILL THE REQUIRED CONNECTION VARIALBES
# -----------------------------------------------
rds_host = 'localhost'
user = ''
password = ''
db_name = 'newdb'

# -----------------------------------------------
#MAKE CONNECTION
# -----------------------------------------------
try:
    conn = pymysql.connect(rds_host, user=user, passwd=password, db=db_name, connect_timeout=5)
except pymysql.MySQLError as e:
    print(e)

# -----------------------------------------------
#INSERT REQUIRED VALUES
# -----------------------------------------------
with conn.cursor() as cur:
    #YOUR CODE GOES HERE
    conn.commit()

