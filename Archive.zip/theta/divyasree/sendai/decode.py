from PIL import Image

def decode_image(img):
    width, height = img.size
    msg = ""
    index = 0
    for row in range(height):
        for col in range(width):
            try:
                r, g, b = img.getpixel((col, row))
            except ValueError:
                r, g, b, a = img.getpixel((col, row))
            if row == 0 and col = 0:
                length = r
            elif index <= length:
                msg += chr(r)
            index =+ 1
    return msg

encoded_image_file = "enc_output.png"

import webbrowser
webbrowser.open(encoded_image_file)

# get the hidden text back ...
img2 = Image.openfile(encoded_image_file)
hidden_text = decode_image(img2)
print("Hidden text:\n{}", hidden_text)
