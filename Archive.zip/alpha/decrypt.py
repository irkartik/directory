'''
Hola Ladies and Gentlemen :P . Congratulations on making into AWS. You guys are happy that you don't have to give exams anymore eh?
Think again! This project will test what you've learned in the training.
Complete the file to get to another step.

Will see you there!!!
'''

import base64

# THIS FUNCTION DECRYPTS THE FILE "ENCRYPTED.TXT".
# -----------------------------------------------
def decrypt_func(data):
    """ YOUR CODE GOES HERE """


    """ YOUR CODE ENDS HERE """
#------------------------------------------------

# THIS FUNCTION WRITES THE DECRYPTED DATA (result) INTO THE FILE "output.txt"
# P.S make sure you use the filename "output.txt". This is important for evaluation.
# ------------------------------------------------
def print_into_file(result):
    """ YOUR CODE GOES HERE """


    """ YOUR CODE ENDS HERE """
# ------------------------------------------------

with open("encrypted.txt") as myfile:
    data = myfile.read()

result=decrypt_func(data)
print(result)
print_into_file(result)
