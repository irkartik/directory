We have an base64 encrypted file for you. Decrypt it and get candies!

Complete the file "decrypt.py" to encrypt the file "encrypted.txt" and print the contents into file named "output.txt"

P.S Keep in mind the names of files as it will affect the evaluated score. All the best!
